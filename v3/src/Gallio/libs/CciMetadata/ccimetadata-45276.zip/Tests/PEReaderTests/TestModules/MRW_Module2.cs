namespace Module2 {

  public class Bar {
    public Module1.Foo Foo1() {
      return new Module1.Foo();
    }
  }
}

